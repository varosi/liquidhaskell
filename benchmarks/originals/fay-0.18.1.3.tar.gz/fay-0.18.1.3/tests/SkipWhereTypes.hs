import Prelude

main = print t
  where
    t :: Bool
    t = True

