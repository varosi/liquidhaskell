import           Prelude

main = putStrLn (case False of
                  True -> "Hello!"
                  _    -> "Ney!")

