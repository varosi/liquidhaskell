module RecordImport2_Export1 (main) where
import Prelude
data R = R { wrong :: Double }

main :: Fay ()
main = return ()
