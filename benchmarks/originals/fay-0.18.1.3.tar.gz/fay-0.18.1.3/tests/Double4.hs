import           Prelude

main = print 1

