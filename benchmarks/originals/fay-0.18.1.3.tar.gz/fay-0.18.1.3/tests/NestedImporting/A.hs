module NestedImporting.A where

import Prelude
import NestedImporting

main :: Fay ()
main = print r
