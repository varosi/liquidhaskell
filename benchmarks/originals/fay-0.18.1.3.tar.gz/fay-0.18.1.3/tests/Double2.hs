import           Prelude

main = print ((10 + (2 * (4 / 2))) :: Double)
