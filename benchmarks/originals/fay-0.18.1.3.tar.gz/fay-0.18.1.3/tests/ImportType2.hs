module ImportType2 where

import ImportType2I.A (foo)
import ImportType2I.B (Foo)

main = foo