module T190_A where

import Prelude

foo :: Int -> Fay ()
foo _ = putStrLn "WRONG!"
