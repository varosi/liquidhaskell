module NestedImporting2 where

import Prelude
import NestedImporting2.A

main :: Fay ()
main = print r
