module ExportEThingAll where

import Prelude
import ExportEThingAll_Export

main = print Barbles
