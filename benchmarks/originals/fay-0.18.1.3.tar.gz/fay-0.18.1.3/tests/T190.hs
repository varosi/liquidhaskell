module T190 where

import Prelude

import T190_B
import T190_C

main :: Fay ()
main = foo "Hello"
