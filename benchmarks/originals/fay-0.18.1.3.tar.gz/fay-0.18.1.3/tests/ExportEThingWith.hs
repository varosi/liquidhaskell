module ExportEThingWith (Bar(Barbles)) where

data Bar = Barbles
