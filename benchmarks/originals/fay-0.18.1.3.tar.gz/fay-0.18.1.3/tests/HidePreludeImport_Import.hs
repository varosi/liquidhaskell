module HidePreludeImport_Import where

import           Prelude

last :: Double
last = 1
