import           Prelude

main :: Fay ()
main =
    let x = 10 :: Int
    in print $ x + y
  where y = 20
