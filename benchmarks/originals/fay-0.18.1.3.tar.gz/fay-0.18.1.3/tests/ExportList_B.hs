module ExportList_B (y, module ExportList_C, module ExportList_D) where

import ExportList_C
import ExportList_D
import Prelude

y :: Double
y = 2
