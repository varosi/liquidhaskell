import Prelude
main = case (f ()) of
  () -> print 123

  where f () = ()
