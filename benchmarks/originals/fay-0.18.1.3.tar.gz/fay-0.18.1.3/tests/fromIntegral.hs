import           Prelude

main :: Fay ()
main = putStrLn $ show $ fromIntegral 5
