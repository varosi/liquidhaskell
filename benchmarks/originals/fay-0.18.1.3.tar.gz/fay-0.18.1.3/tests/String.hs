import           Prelude

main = putStrLn "Hello, World!"

