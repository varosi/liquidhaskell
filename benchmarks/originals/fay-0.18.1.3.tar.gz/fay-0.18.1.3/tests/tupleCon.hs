import Prelude

main = do
  print $ (,) 1 2
  print $ (,,) 1 2 3
  print $ (,,,) 1 2 3 4
