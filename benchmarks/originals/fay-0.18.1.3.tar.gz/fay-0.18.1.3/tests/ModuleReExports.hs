{-# LANGUAGE NamedFieldPuns #-}

module ModuleReExports where

import ModuleReExport.ExportsModule

main = putStrLn (div ())
