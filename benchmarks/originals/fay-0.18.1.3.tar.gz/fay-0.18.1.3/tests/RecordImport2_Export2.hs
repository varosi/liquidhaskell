module RecordImport2_Export2 where
import Prelude
data R = R { correct :: Double }
