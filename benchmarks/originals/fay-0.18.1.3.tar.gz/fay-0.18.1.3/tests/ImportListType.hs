import Prelude (Fay, putStrLn)

main :: Fay ()
main = putStrLn "ok"
