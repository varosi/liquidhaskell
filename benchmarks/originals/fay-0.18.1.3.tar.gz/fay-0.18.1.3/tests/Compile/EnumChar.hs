module EnumChar where

import           Prelude

f :: [Char]
f = ['a'..'z']

main :: Fay ()
main = print f
