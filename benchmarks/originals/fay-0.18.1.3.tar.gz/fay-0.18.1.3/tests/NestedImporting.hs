module NestedImporting where

import Prelude

r :: Double
r = 1
