module ExportEThingAll_Export (Bar(..)) where

data Bar = Barbles
