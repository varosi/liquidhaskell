module ExportList_C where

c = 42
