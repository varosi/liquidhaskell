import           Prelude

main = putStrLn "Hello," >> putStrLn "World!"

