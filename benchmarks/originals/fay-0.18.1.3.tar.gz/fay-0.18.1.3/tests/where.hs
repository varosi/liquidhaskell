import           Prelude

main = putStrLn $ "Hello " ++ friends ++ family
  where friends = "my friends"
        family = " and family"

