module RecordExport where

import Prelude
import FFI
import RecordImport2_Export1
import RecordImport2_Export2

main :: Fay ()
main = print $ R 1
