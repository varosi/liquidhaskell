import           Prelude

main = putStrLn ((\a 'a' -> "OK.") 0 'b')

