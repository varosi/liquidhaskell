{-# LANGUAGE OverloadedStrings, RebindableSyntax #-}
module FromString.DepDep where

import Prelude
import FromString.FayText

myText :: Text
myText = "This is also not a String"

