module Issue215A where

import Prelude
import Issue215.B

main = do
        print $ f 2
