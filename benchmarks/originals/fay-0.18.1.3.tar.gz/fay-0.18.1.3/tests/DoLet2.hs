module DoLet2 where

import Prelude
import FFI

main = do
  print 1
  let [a,b] = [3]
  print a
