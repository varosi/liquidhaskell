import           Prelude

main = putStrLn (case False of
                   True -> "Hello!"
                   False -> "Ney!")

