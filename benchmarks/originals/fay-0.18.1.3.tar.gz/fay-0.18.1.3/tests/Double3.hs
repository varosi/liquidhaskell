import           Prelude

main = print ((5 * 3 / 2) :: Double)
