module ImportType2I.B where

import Prelude

data Foo

foo = putStrLn "B!"