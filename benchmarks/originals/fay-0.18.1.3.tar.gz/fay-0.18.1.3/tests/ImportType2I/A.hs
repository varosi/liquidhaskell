module ImportType2I.A where

import Prelude

foo = putStrLn "A"