import           Prelude

main = print ((2 * 4 / 2) :: Double)
