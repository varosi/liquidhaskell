module Hierarchical.Export where

import           FFI
import           Prelude

exported :: String
exported = "exported"
