module ModuleRecordClash.R where

import Prelude

i :: Double
i = 1
