module QualifiedImport.X where

import           Prelude

x :: Double
x = 1

data X2 = X3 { x4 :: Double }
