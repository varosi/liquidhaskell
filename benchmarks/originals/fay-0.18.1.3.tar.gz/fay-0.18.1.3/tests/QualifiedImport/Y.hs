module QualifiedImport.Y where

import           Prelude

y :: Double
y = 2
