module ModuleReExport.ExportsIdentifier where

import Prelude

div :: () -> String
div _ = "I am the identifier!"

div' = "bob"
