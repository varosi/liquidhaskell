import           Prelude
import           Hierarchical.Export

main :: Fay ()
main = putStrLn exported

