import           Prelude

main :: Fay ()
main = putStrLn $ show $ fromInteger 5
