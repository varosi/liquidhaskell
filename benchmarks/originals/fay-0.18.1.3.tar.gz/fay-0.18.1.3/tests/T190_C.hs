module T190_C where

import Prelude

foo :: String -> Fay ()
foo x = putStrLn x
