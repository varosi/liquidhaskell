module ImportList1.A where

import           Prelude
import           FFI

x :: Double
x = 1

y :: Double
y = 1

data R = S
