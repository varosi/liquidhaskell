import Prelude
import ReExport2

main :: Fay ()
main = print x
