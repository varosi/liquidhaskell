import           Prelude

main :: Fay ()
main = print (-10 :: Double)

