import           Prelude

main = do
  print 123

