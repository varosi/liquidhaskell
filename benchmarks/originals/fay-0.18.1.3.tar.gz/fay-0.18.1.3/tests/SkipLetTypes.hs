import Prelude

main = let t :: Bool
           t = True
       in print t

