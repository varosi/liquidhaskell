module T190_B where

import           Prelude
import           T190_A

main :: Fay ()
main = return ()
