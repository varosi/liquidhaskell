import           Prelude

main = putStrLn (case True of
                   True -> "Hello!"
                   False -> "Ney!")

