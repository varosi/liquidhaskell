module Issue215.B where

import Prelude

f :: Int -> Maybe Int
f x = Just x
