import Prelude

main = do
  print $ (subtract 3 5 :: Int)
  print $ even 4
  print $ even 3
  print $ odd 4
  print $ odd 3
  print $ gcd (-3) (-2)
  print $ lcm 6 10
  print $ (4^5 :: Int)
  print $ 4^^(-2)
