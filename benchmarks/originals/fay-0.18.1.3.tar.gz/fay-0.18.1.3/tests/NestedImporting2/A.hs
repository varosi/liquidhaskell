module NestedImporting2.A where

import Prelude

r :: Double
r = 1
