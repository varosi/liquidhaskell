module ReExport1 where

x = 42

