import Prelude

main = do
  print (succ 1 :: Int)
  print (pred 1 :: Int)
