import Prelude

main = error "You shall not pass!" `seq` return ()
