import Prelude

main :: Fay ()
main = print True
