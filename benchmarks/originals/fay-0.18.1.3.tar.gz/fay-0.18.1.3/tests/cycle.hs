import Prelude

main = mapM_ putStrLn (take 5 (cycle ["a", "b", "c"]))
