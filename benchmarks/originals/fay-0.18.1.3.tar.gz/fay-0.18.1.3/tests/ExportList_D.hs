module ExportList_D(module ExportList_D) where

d = 64
