import Prelude

main = error "This is an error"
