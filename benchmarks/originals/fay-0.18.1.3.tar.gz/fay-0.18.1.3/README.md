# Fay programming language

[![Build Status](https://secure.travis-ci.org/faylang/fay.png?branch=master)](http://travis-ci.org/faylang/fay)

We use the Github wiki for our home page and documentation: https://github.com/faylang/fay/wiki

[Changelog](CHANGELOG.md)
