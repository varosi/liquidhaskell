{-# LANGUAGE PackageImports #-}
{-# LANGUAGE NoImplicitPrelude #-}
{-# LANGUAGE CPP #-}
module Data.Data
#ifndef FAY
  (Data,Typeable)
#endif
  where

import "base" Data.Data
