module FFI
  (module Fay.FFI)
  where

import Fay.FFI
