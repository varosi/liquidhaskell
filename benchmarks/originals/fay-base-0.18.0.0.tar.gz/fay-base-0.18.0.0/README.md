# fay-base

This package exports Prelude and FFI which you probably want to use with [Fay](http://www.fay-lang.org).

Anything essential for using the compiler, or modules exported by GHC's base can go in this package.
